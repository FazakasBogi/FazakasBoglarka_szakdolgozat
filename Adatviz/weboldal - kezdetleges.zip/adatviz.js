let weeeCollectionView = null;
let recyclingRateView = null;
const chartSpec = {
  $schema: "https://vega.github.io/schema/vega-lite/v5.json",
  title: {
    text: "WEEE begyűjtés országonként és kategóriánként (2019-2023)",
    subtitle: "Minden évben külön oszlopon látszik Hollandia és Románia, kategóriánként egymásra halmozva",
    anchor: "start",
    fontSize: 18,
    subtitleFontSize: 13,
    offset: 16,
  },
  data: {
    values: [
      { Category: "Nagy gépek", Country: "Hollandia", Year: 2019, Value: 118002 },
      { Category: "Nagy gépek", Country: "Hollandia", Year: 2020, Value: 137312 },
      { Category: "Nagy gépek", Country: "Hollandia", Year: 2021, Value: 132800 },
      { Category: "Nagy gépek", Country: "Hollandia", Year: 2022, Value: 129593 },
      { Category: "Nagy gépek", Country: "Hollandia", Year: 2023, Value: 131069 },
      { Category: "Személyes IT eszközök", Country: "Hollandia", Year: 2019, Value: 39508 },
      { Category: "Személyes IT eszközök", Country: "Hollandia", Year: 2020, Value: 38627 },
      { Category: "Személyes IT eszközök", Country: "Hollandia", Year: 2021, Value: 35035 },
      { Category: "Személyes IT eszközök", Country: "Hollandia", Year: 2022, Value: 29413 },
      { Category: "Személyes IT eszközök", Country: "Hollandia", Year: 2023, Value: 36625 },
      { Category: "kis eszközök", Country: "Hollandia", Year: 2019, Value: 41139 },
      { Category: "kis eszközök", Country: "Hollandia", Year: 2020, Value: 44297 },
      { Category: "kis eszközök", Country: "Hollandia", Year: 2021, Value: 38156 },
      { Category: "kis eszközök", Country: "Hollandia", Year: 2022, Value: 40464 },
      { Category: "kis eszközök", Country: "Hollandia", Year: 2023, Value: 51762 },
      { Category: "Nagy gépek", Country: "Románia", Year: 2019, Value: 60618 },
      { Category: "Nagy gépek", Country: "Románia", Year: 2020, Value: 65608 },
      { Category: "Nagy gépek", Country: "Románia", Year: 2021, Value: 106484 },
      { Category: "Személyes IT eszközök", Country: "Románia", Year: 2019, Value: 19100 },
      { Category: "Személyes IT eszközök", Country: "Románia", Year: 2020, Value: 15725 },
      { Category: "Személyes IT eszközök", Country: "Románia", Year: 2021, Value: 25816 },
      { Category: "kis eszközök", Country: "Románia", Year: 2019, Value: 9153 },
      { Category: "kis eszközök", Country: "Románia", Year: 2020, Value: 9461 },
      { Category: "kis eszközök", Country: "Románia", Year: 2021, Value: 13608 },
    ],
  },
  transform: [
    {
      calculate: "datum.Country + ' - ' + datum.Category",
      as: "CountryCategory",
    },
  ],
  width: "container",
  height: 420,
  autosize: { type: "fit-x", contains: "padding" },
  mark: {
    type: "bar",
    cornerRadiusTopLeft: 3,
    cornerRadiusTopRight: 3,
    opacity: 0.92,
  },
  encoding: {
    x: {
      field: "Year",
      type: "ordinal",
      title: "Év",
      axis: { labelAngle: 0, grid: false },
    },
    xOffset: {
      field: "Country",
      sort: ["Hollandia", "Románia"],
      title: "Ország",
    },
    y: {
      field: "Value",
      type: "quantitative",
      title: "Begyűjtött e-hulladék (tonna)",
      stack: "zero",
      axis: { grid: true, tickCount: 6, format: "~s" },
    },
    color: {
      field: "CountryCategory",
      type: "nominal",
      title: "Ország / Kategória",
      scale: {
        domain: [
          "Hollandia - Nagy gépek",
          "Hollandia - Személyes IT eszközök",
          "Hollandia - kis eszközök",
          "Románia - Nagy gépek",
          "Románia - Személyes IT eszközök",
          "Románia - kis eszközök",
        ],
        range: [
          "#F97316",
          "#FB923C",
          "#FDBA74",
          "#2563EB",
          "#60A5FA",
          "#93C5FD",
        ],
      },
    },
    order: {
      field: "Category",
      sort: ["Nagy gépek", "Személyes IT eszközök", "kis eszközök"],
    },
    tooltip: [
      { field: "Year", title: "Év" },
      { field: "Country", title: "Ország" },
      { field: "Category", title: "Kategória" },
      { field: "Value", title: "Begyűjtött mennyiség (tonna)", format: "," },
    ],
  },
  config: {
    view: { stroke: "#E5E7EB" },
    axis: {
      labelFontSize: 11,
      titleFontSize: 12,
      titleColor: "#374151",
      labelColor: "#4B5563",
      gridColor: "#E5E7EB",
    },
    legend: {
      titleFontSize: 12,
      labelFontSize: 11,
      orient: "top",
      direction: "horizontal",
      symbolType: "square",
      symbolSize: 110,
      labelColor: "#374151",
      titleColor: "#111827",
    },
    background: "#FFFFFF",
  },
};

async function renderChart() {
  const chartContainer = document.getElementById("chart");
  if (!chartContainer) {
    console.error("Chart container not found.");
    return;
  }

  try {
    const result = await vegaEmbed("#chart", chartSpec, {
      actions: false,
      renderer: "svg",
      width: "container",
      tooltip: true,
    });
    weeeCollectionView = result.view;
  } catch (error) {
    console.error("Failed to render Vega-Lite chart:", error);
    chartContainer.innerHTML = "<p>A diagram nem jeleníthető meg.</p>";
  }
}

async function renderRecyclingRateChart() {
  const chartContainer = document.getElementById("chartRate");
  if (!chartContainer) {
    console.error("Recycling rate chart container not found.");
    return;
  }

  try {
    const result = await vegaEmbed("#chartRate", "weee_recycling_chart.json", {
      actions: false,
      renderer: "svg",
      width: "container",
      tooltip: true,
    });
    recyclingRateView = result.view;
  } catch (error) {
    console.error("Failed to render recycling rate chart:", error);
    chartContainer.innerHTML = "<p>A diagram nem jeleníthető meg.</p>";
  }
}

async function downloadViewAsImage(view, filename) {
  if (!view) {
    console.error("Chart view is not ready.");
    return;
  }

  try {
    const imageUrl = await view.toImageURL("png");
    const link = document.createElement("a");
    link.href = imageUrl;
    link.download = filename;
    link.click();
  } catch (error) {
    console.error("Failed to export chart image:", error);
  }
}

document.addEventListener("DOMContentLoaded", () => {
  renderChart();
  renderRecyclingRateChart();

  const downloadChartBtn = document.getElementById("downloadChartBtn");
  if (downloadChartBtn) {
    downloadChartBtn.addEventListener("click", () =>
      downloadViewAsImage(weeeCollectionView, "weee_begyujtes_diagram.png")
    );
  }

  const downloadRateBtn = document.getElementById("downloadRateBtn");
  if (downloadRateBtn) {
    downloadRateBtn.addEventListener("click", () =>
      downloadViewAsImage(recyclingRateView, "weee_ujrahasznositas_diagram.png")
    );
  }
});
